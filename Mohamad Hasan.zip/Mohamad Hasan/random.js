window.onload = function() {
    var x = []; // the array that will contain all random numbers generated
    var count = 0; // tracks the index of the current random number in the array
    var prev = 0; //  before the current index (count-1), however it's used when the user presses on the previous button to view previous images
    const url = 'https://xkcd.now.sh';

    // fetch the first image that should appear to the user when he opens the page
    showNext();
    
    // handling when the user clicks on Next to show him/her a new random image
    document.getElementById("next").onclick = function(){
        showNext();
    }
    
    // handling when the user clicks on Previous to show him/her the previous images he/she viewed
    document.getElementById("previous").onclick = function(){
        showPrev();
    }
    
    // function that fetches random images from xkcd API, show them to the user, and provides a table(list) of viewed images with the time they were seen
    function showNext(){
        // generate a random number between 1 and 2100 to append it to the url
        var random = Math.floor(Math.random() * 2100) + 1;         
        x.push(random); // add the random number to the array
        
        
        // fetch the url with a random number appeneded in order to choose a random picture
        fetch(url+"/"+random)      
        // get the json data
        .then((resp) => resp.json())  
            // from the json data, get the img and the title elements
            .then(data => {         
                document.getElementById("myImage").src = data["img"];

                // add this link to the head of the html to speed up our image loading
                // once the page finishes loading, the browser will start to prefetch the image
                link=document.getElementById("myLink");
                link.href= data["img"];
                link.rel='prefetch';

                // get the date when the image is viewed by the user
                var now = new Date();
                var myDate = (now.getMonth() + 1) + '/' + (now.getDate()) + '/' + now.getFullYear() + " " + now.getHours() + ':'
                + ((now.getMinutes() < 10) ? ("0" + now.getMinutes()) : (now.getMinutes())) + ':' + ((now.getSeconds() < 10) ? ("0" + now.getSeconds()) : (now.getSeconds()));
                
                // add the title of the image and the time it was viewed to the list, and keep on updating the list whenever the user views every other image
                var table = document.getElementById("myTablee");
                var tbody = table.getElementsByTagName("tbody")[0];
                var row = document.createElement("tr");
                var cell1 = document.createElement("td");
                var cell2 = document.createElement("td");
                row.appendChild(cell1);
                row.appendChild(cell2);
                tbody.appendChild(row);
                
                // the title of the image found on the list is a link that directs you to that specific image
                var titleLink = document.createElement('a');
                titleLink.href = data["img"];
                titleLink.innerText = data["title"];
                titleLink.style.textDecoration = "none";
                cell1.appendChild(titleLink);
                cell1.style.textAlign = "center";
                
                // add the time to the list
                cell2.innerHTML = myDate;
                cell2.style.textAlign = "center";
                cell2.style.color = "white";
                
                count++; // current index
                prev = count-1; // current index's predecessor
            })
        // error handling
        .catch(function(error) {
            console.log(JSON.stringify(error));
        }); 
    }
    
    // function that fetches previously fetched images when the user presses on Previous 
    function showPrev(){
        --prev;
        var index = x[prev]; // the random number that was in the previous index will be the one appended to the url to be fetched
        
        fetch(url+"/"+index)      
        // get the json data
        .then((resp) => resp.json())  
            // from the json data, get the img and the title elements
            .then(data => {         
                document.getElementById("myImage").src = data["img"];
            })
    }                          
}